# Payroll-Management-System

A simple Payroll Management System where you can 

Add
Update
Delete
Search 

Employees from the System

Add
Update
Delete 

Salary details

Add
Update
Delete 

Leave details 

Generate and Print Pay Slips

Database file is also included

GUI is done using Java Swing Framework
